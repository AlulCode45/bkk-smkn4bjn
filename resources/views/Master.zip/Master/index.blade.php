@extends('Template.app')
@section('content')
    <h1>Ini Master</h1>
@endsection
